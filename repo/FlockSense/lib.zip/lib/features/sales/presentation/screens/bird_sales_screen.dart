import 'package:flutter/material.dart';
import 'package:flock_sense/core/theme/app_colors.dart';

class BirdSalesScreen extends StatelessWidget {
  const BirdSalesScreen({super.key, this.farmId, this.batchId, this.batchName});

  final String? farmId;
  final String? batchId;
  final String? batchName;

  bool get _hasContext =>
      (farmId?.isNotEmpty ?? false) && (batchId?.isNotEmpty ?? false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(batchName == null ? 'Sales' : 'Sales • $batchName'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Bird sales ledger',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _hasContext
                        ? 'Track sold birds, live weight, and sale value for this batch.'
                        : 'Open sales from a batch to log transaction details accurately.',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: const [
                  Icon(
                    Icons.point_of_sale_outlined,
                    size: 56,
                    color: AppColors.textHint,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'No sales records yet',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Sales data will appear here after you log your first sale entry.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: _hasContext
          ? FloatingActionButton.extended(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Sales form will be added in the next pass.'),
                  ),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Add Sale'),
            )
          : null,
    );
  }
}
