import 'package:flutter/material.dart';
import 'package:flock_sense/core/theme/app_colors.dart';

class MedicineRecordsScreen extends StatelessWidget {
  const MedicineRecordsScreen({
    super.key,
    this.farmId,
    this.batchId,
    this.batchName,
  });

  final String? farmId;
  final String? batchId;
  final String? batchName;

  bool get _hasContext =>
      (farmId?.isNotEmpty ?? false) && (batchId?.isNotEmpty ?? false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(batchName == null ? 'Medicine' : 'Medicine • $batchName'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Medicine log',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _hasContext
                        ? 'Track treatments, dose, and reason for this batch.'
                        : 'Open medicine from a batch to track treatment records precisely.',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: const [
                  Icon(
                    Icons.medication_outlined,
                    size: 56,
                    color: AppColors.textHint,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'No medicine records yet',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Medicine tracking UI is ready. Data entry actions will appear here once records are added.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: _hasContext
          ? FloatingActionButton.extended(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Medicine form will be added in the next pass.',
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Add Medicine'),
            )
          : null,
    );
  }
}
