class MedicineFeature {
  MedicineFeature._();
}
