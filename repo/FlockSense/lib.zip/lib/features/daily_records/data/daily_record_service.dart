import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flock_sense/core/exceptions/app_exceptions.dart';
import 'package:flock_sense/features/daily_records/domain/daily_record_model.dart';

class DailyRecordService {
  DailyRecordService._();

  static final _db = FirebaseFirestore.instance;
  static final _auth = FirebaseAuth.instance;

  static CollectionReference<Map<String, dynamic>> _dailyRecordsRef(
    String uid,
    String farmId,
    String batchId,
  ) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('farms')
        .doc(farmId)
        .collection('batches')
        .doc(batchId)
        .collection('dailyRecords');
  }

  static Future<DailyRecordModel> createOrUpdateDailyRecord({
    required String farmId,
    required String batchId,
    required DateTime recordDate,
    required int batchAgeDay,
    required int openingBirds,
    required int mortalityCount,
    required int cullCount,
    required double feedConsumedKg,
    required double waterConsumedLiters,
    required double avgWeightGrams,
    required bool medicineGiven,
    String? medicineName,
    required bool vaccineGiven,
    String? vaccineName,
    String? symptoms,
    String? notes,
  }) async {
    final user = _auth.currentUser;
    if (user == null) throw AuthException('Sign in before saving daily records.');

    if (openingBirds < 0) throw ValidationException('Opening birds must be zero or positive.');
    if (mortalityCount < 0) throw ValidationException('Mortality count must be zero or positive.');
    if (cullCount < 0) throw ValidationException('Cull count must be zero or positive.');

    final closingBirds = openingBirds - mortalityCount - cullCount;
    if (closingBirds < 0) throw ValidationException('Closing birds cannot be negative.');
    if (medicineGiven && (medicineName?.trim().isEmpty ?? true)) {
      throw ValidationException('Medicine name is required when medicine is given.');
    }
    if (vaccineGiven && (vaccineName?.trim().isEmpty ?? true)) {
      throw ValidationException('Vaccine name is required when vaccine is given.');
    }

    final recordId = _formatRecordDate(recordDate);
    final recordRef = _dailyRecordsRef(user.uid, farmId, batchId).doc(recordId);
    final batchRef = _batchesRef(user.uid, farmId).doc(batchId);

    final existingSnapshot = await recordRef.get();
    final createdAt = existingSnapshot.exists
        ? _parseTimestamp(existingSnapshot.data()?['createdAt']) ?? DateTime.now()
        : DateTime.now();

    final record = DailyRecordModel(
      id: recordId,
      farmId: farmId,
      batchId: batchId,
      recordDate: recordDate,
      batchAgeDay: batchAgeDay,
      openingBirds: openingBirds,
      mortalityCount: mortalityCount,
      cullCount: cullCount,
      closingBirds: closingBirds,
      feedConsumedKg: feedConsumedKg,
      waterConsumedLiters: waterConsumedLiters,
      avgWeightGrams: avgWeightGrams,
      medicineGiven: medicineGiven,
      medicineName: medicineName?.trim(),
      vaccineGiven: vaccineGiven,
      vaccineName: vaccineName?.trim(),
      symptoms: symptoms?.trim(),
      notes: notes?.trim(),
      ownerId: user.uid,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );

    final latestExistingRecord = await getLatestRecordBeforeDate(
      farmId: farmId,
      batchId: batchId,
      beforeDate: recordDate,
    );
    final shouldUpdateBatchSummary = latestExistingRecord == null ||
        latestExistingRecord.recordDate.isBefore(recordDate) ||
        latestExistingRecord.recordDate.isAtSameMomentAs(recordDate);

    final batch = _db.batch();
    batch.set(recordRef, record.toJson());
    if (shouldUpdateBatchSummary) {
      batch.update(batchRef, {
        'currentBirds': closingBirds,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();

    return record;
  }

  static Stream<List<DailyRecordModel>> watchDailyRecords({
    required String farmId,
    required String batchId,
  }) {
    final user = _auth.currentUser;
    if (user == null) return const Stream.empty();

    return _dailyRecordsRef(user.uid, farmId, batchId)
        .orderBy('recordDate', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => DailyRecordModel.fromJson(doc.data()))
            .toList());
  }

  static Future<DailyRecordModel?> getDailyRecordByDate({
    required String farmId,
    required String batchId,
    required DateTime recordDate,
  }) async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final recordId = _formatRecordDate(recordDate);
    final snapshot = await _dailyRecordsRef(user.uid, farmId, batchId).doc(recordId).get();
    if (!snapshot.exists) return null;
    return DailyRecordModel.fromJson(snapshot.data()!);
  }

  static Future<int> getTodayMortalityCount(String uid) async {
    final farms = await _db.collection('users').doc(uid).collection('farms').get();
    if (farms.docs.isEmpty) return 0;

    final todayId = _formatRecordDate(DateTime.now());
    var total = 0;

    for (final farmDoc in farms.docs) {
      final batchSnapshot = await farmDoc.reference
          .collection('batches')
          .where('status', isEqualTo: 'active')
          .get();
      for (final batchDoc in batchSnapshot.docs) {
        final recordDoc = await batchDoc.reference.collection('dailyRecords').doc(todayId).get();
        if (!recordDoc.exists) continue;
        final data = recordDoc.data();
        if (data == null) continue;
        final mortality = data['mortalityCount'];
        if (mortality is int) {
          total += mortality;
        } else if (mortality is double) {
          total += mortality.toInt();
        } else if (mortality is String) {
          total += int.tryParse(mortality) ?? 0;
        }
      }
    }

    return total;
  }

  static Future<DailyRecordModel?> getLatestRecordBeforeDate({
    required String farmId,
    required String batchId,
    required DateTime beforeDate,
  }) async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final snapshot = await _dailyRecordsRef(user.uid, farmId, batchId)
        .where('recordDate', isLessThanOrEqualTo: _formatRecordDate(beforeDate))
        .orderBy('recordDate', descending: true)
        .limit(1)
        .get();

    if (snapshot.docs.isEmpty) return null;
    return DailyRecordModel.fromJson(snapshot.docs.first.data());
  }

  static Future<DailyRecordModel?> getBatchLatestRecord({
    required String farmId,
    required String batchId,
  }) async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final snapshot = await _dailyRecordsRef(user.uid, farmId, batchId)
        .orderBy('recordDate', descending: true)
        .limit(1)
        .get();

    if (snapshot.docs.isEmpty) return null;
    return DailyRecordModel.fromJson(snapshot.docs.first.data());
  }

  static CollectionReference<Map<String, dynamic>> _batchesRef(
      String uid,
      String farmId,
      ) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('farms')
        .doc(farmId)
        .collection('batches');
  }

  static String _formatRecordDate(DateTime date) {
    return '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  static DateTime? _parseTimestamp(dynamic value) {
    if (value is Timestamp) return value.toDate();
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}
