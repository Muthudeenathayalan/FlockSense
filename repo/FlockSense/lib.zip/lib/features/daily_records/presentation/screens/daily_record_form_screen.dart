import 'package:flutter/material.dart';
import 'package:flock_sense/core/theme/app_colors.dart';
import 'package:flock_sense/features/batches/data/batch_service.dart';
import 'package:flock_sense/features/daily_records/data/daily_record_service.dart';
import 'package:flock_sense/features/daily_records/domain/daily_record_model.dart';

class DailyRecordFormScreen extends StatefulWidget {
  const DailyRecordFormScreen({
    super.key,
    required this.farmId,
    required this.batchId,
    this.batchName,
    this.existingRecord,
  });

  final String farmId;
  final String batchId;
  final String? batchName;
  final DailyRecordModel? existingRecord;

  @override
  State<DailyRecordFormScreen> createState() => _DailyRecordFormScreenState();
}

class _DailyRecordFormScreenState extends State<DailyRecordFormScreen> {
  final _pageController = PageController();
  final _stepOneKey = GlobalKey<FormState>();
  final _stepTwoKey = GlobalKey<FormState>();

  late DateTime _recordDate;
  late TextEditingController _ageController;
  late TextEditingController _openingController;
  late TextEditingController _mortalityController;
  late TextEditingController _cullController;
  late TextEditingController _closingController;
  late TextEditingController _feedController;
  late TextEditingController _waterController;
  late TextEditingController _weightController;
  late TextEditingController _medicineNameController;
  late TextEditingController _vaccineNameController;
  late TextEditingController _symptomsController;
  late TextEditingController _notesController;

  bool _medicineGiven = false;
  bool _vaccineGiven = false;
  bool _saving = false;
  int _step = 0;

  @override
  void initState() {
    super.initState();
    final record = widget.existingRecord;
    _recordDate = record?.recordDate ?? DateTime.now();
    _ageController = TextEditingController(
      text: (record?.batchAgeDay ?? 0).toString(),
    );
    _openingController = TextEditingController(
      text: (record?.openingBirds ?? 0).toString(),
    );
    _mortalityController = TextEditingController(
      text: (record?.mortalityCount ?? 0).toString(),
    );
    _cullController = TextEditingController(
      text: (record?.cullCount ?? 0).toString(),
    );
    _closingController = TextEditingController(
      text: (record?.closingBirds ?? 0).toString(),
    );
    _feedController = TextEditingController(
      text: _formatOptionalNumber(record?.feedConsumedKg),
    );
    _waterController = TextEditingController(
      text: _formatOptionalNumber(record?.waterConsumedLiters),
    );
    _weightController = TextEditingController(
      text: _formatOptionalNumber(record?.avgWeightGrams),
    );
    _medicineGiven = record?.medicineGiven ?? false;
    _vaccineGiven = record?.vaccineGiven ?? false;
    _medicineNameController = TextEditingController(
      text: record?.medicineName ?? '',
    );
    _vaccineNameController = TextEditingController(
      text: record?.vaccineName ?? '',
    );
    _symptomsController = TextEditingController(text: record?.symptoms ?? '');
    _notesController = TextEditingController(text: record?.notes ?? '');

    _syncClosing();
    if (record == null) {
      _loadDefaults();
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    _ageController.dispose();
    _openingController.dispose();
    _mortalityController.dispose();
    _cullController.dispose();
    _closingController.dispose();
    _feedController.dispose();
    _waterController.dispose();
    _weightController.dispose();
    _medicineNameController.dispose();
    _vaccineNameController.dispose();
    _symptomsController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadDefaults() async {
    final batch = await BatchService.getBatchById(
      widget.farmId,
      widget.batchId,
    );
    if (!mounted || batch == null) return;

    final age = _recordDate.difference(batch.placementDate).inDays + 1;
    final priorRecord = await DailyRecordService.getLatestRecordBeforeDate(
      farmId: widget.farmId,
      batchId: widget.batchId,
      beforeDate: _recordDate,
    );
    final opening = priorRecord?.closingBirds ?? (batch.currentBirds > 0 ? batch.currentBirds : batch.totalBirds);

    setState(() {
      _ageController.text = age < 0 ? '0' : age.toString();
      _openingController.text = opening.toString();
      _mortalityController.text = '';
      _cullController.text = '';
      _feedController.text = '';
      _waterController.text = '';
      _weightController.text = '';
      _syncClosing();
    });
  }

  void _syncClosing() {
    final opening = int.tryParse(_openingController.text.trim()) ?? 0;
    final mortality = int.tryParse(_mortalityController.text.trim()) ?? 0;
    final cull = int.tryParse(_cullController.text.trim()) ?? 0;
    final closing = opening - mortality - cull;
    _closingController.text = closing < 0 ? '0' : closing.toString();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _recordDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked == null) return;
    setState(() => _recordDate = picked);
    if (widget.existingRecord == null) {
      await _loadDefaults();
    }
  }

  void _dismissKeyboard() {
    FocusScope.of(context).unfocus();
  }

  Future<void> _save() async {
    final opening = int.tryParse(_openingController.text.trim()) ?? 0;
    final mortality = int.tryParse(_mortalityController.text.trim()) ?? 0;
    final cull = int.tryParse(_cullController.text.trim()) ?? 0;
    if ((opening - mortality - cull) < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Closing birds cannot be negative.')),
      );
      return;
    }

    setState(() => _saving = true);
    try {
      await DailyRecordService.createOrUpdateDailyRecord(
        farmId: widget.farmId,
        batchId: widget.batchId,
        recordDate: _recordDate,
        batchAgeDay: int.tryParse(_ageController.text.trim()) ?? 0,
        openingBirds: opening,
        mortalityCount: mortality,
        cullCount: cull,
        feedConsumedKg: double.tryParse(_feedController.text.trim()) ?? 0,
        waterConsumedLiters: double.tryParse(_waterController.text.trim()) ?? 0,
        avgWeightGrams: double.tryParse(_weightController.text.trim()) ?? 0,
        medicineGiven: _medicineGiven,
        medicineName: _medicineNameController.text.trim(),
        vaccineGiven: _vaccineGiven,
        vaccineName: _vaccineNameController.text.trim(),
        symptoms: _symptomsController.text.trim(),
        notes: _notesController.text.trim(),
      );

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Unable to save record: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _next() {
    if (_step == 0) {
      final valid = _stepOneKey.currentState?.validate() ?? false;
      if (!valid) return;
      setState(() => _step = 1);
      _pageController.nextPage(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
      return;
    }

    // Step 1: Validate step 2 form before saving
    final twoValid = _stepTwoKey.currentState?.validate() ?? false;
    if (!twoValid) return;

    _save();
  }

  void _back() {
    if (_step == 0) {
      Navigator.of(context).maybePop();
      return;
    }
    setState(() => _step = 0);
    _pageController.previousPage(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _dismissKeyboard,
      behavior: HitTestBehavior.opaque,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: Text(
            widget.batchName == null
                ? 'Add Daily Record'
                : 'Record • ${widget.batchName}',
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: _WizardHeader(step: _step),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [_stepOne(), _stepTwo()],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _saving ? null : _back,
                      child: const Text('Back'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: _saving ? null : _next,
                      child: _saving
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(_step == 1 ? 'Save Record' : 'Next'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stepOne() {
    return Form(
      key: _stepOneKey,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        children: [
          _SectionCard(
            title: 'Bird counts',
            subtitle: 'Daily opening and losses.',
            child: Column(
              children: [
                _DateField(date: _recordDate, onTap: _pickDate),
                const SizedBox(height: 12),
                _intField(_ageController, 'Batch age day', required: true),
                const SizedBox(height: 12),
                _intField(
                  _openingController,
                  'Opening birds',
                  required: true,
                  onChanged: (_) => setState(_syncClosing),
                ),
                const SizedBox(height: 12),
                _intField(
                  _mortalityController,
                  'Mortality count',
                  onChanged: (_) => setState(_syncClosing),
                ),
                const SizedBox(height: 12),
                _intField(
                  _cullController,
                  'Cull count',
                  onChanged: (_) => setState(_syncClosing),
                ),
                const SizedBox(height: 12),
                _intField(_closingController, 'Closing birds', enabled: false),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _stepTwo() {
    return Form(
      key: _stepTwoKey,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        children: [
          _SectionCard(
            title: 'Consumption & health',
            subtitle: 'Feed, water, weight, and treatments.',
            child: Column(
              children: [
                _doubleField(_feedController, 'Feed consumed (kg)'),
                const SizedBox(height: 12),
                _doubleField(_waterController, 'Water consumed (L)'),
                const SizedBox(height: 12),
                _doubleField(_weightController, 'Avg weight (g)'),
                const SizedBox(height: 10),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Medicine given'),
                  value: _medicineGiven,
                  onChanged: (value) => setState(() => _medicineGiven = value),
                ),
                if (_medicineGiven) ...[
                  _textField(
                    _medicineNameController,
                    'Medicine name',
                    validator: (value) {
                      if (!_medicineGiven) return null;
                      if (value == null || value.trim().isEmpty)
                        return 'Required';
                      return null;
                    },
                  ),
                ],
                const SizedBox(height: 10),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Vaccine given'),
                  value: _vaccineGiven,
                  onChanged: (value) => setState(() => _vaccineGiven = value),
                ),
                if (_vaccineGiven) ...[
                  _textField(
                    _vaccineNameController,
                    'Vaccine name',
                    validator: (value) {
                      if (!_vaccineGiven) return null;
                      if (value == null || value.trim().isEmpty)
                        return 'Required';
                      return null;
                    },
                  ),
                ],
                const SizedBox(height: 10),
                _textField(_symptomsController, 'Symptoms'),
                const SizedBox(height: 12),
                _textField(_notesController, 'Notes', maxLines: 3),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatOptionalNumber(double? value) {
    if (value == null || value <= 0) return '';
    return value.toString();
  }

  Widget _intField(
    TextEditingController controller,
    String label, {
    bool required = false,
    bool enabled = true,
    void Function(String)? onChanged,
  }) {
    return TextFormField(
      controller: controller,
      enabled: enabled,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(labelText: label),
      onChanged: onChanged,
      validator: (value) {
        if (!enabled) return null;
        if (!required && (value == null || value.trim().isEmpty)) return null;
        final parsed = int.tryParse(value?.trim() ?? '');
        if (parsed == null || parsed < 0) return 'Enter a valid number';
        return null;
      },
    );
  }

  Widget _doubleField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label),
      validator: (value) {
        if (value == null || value.trim().isEmpty) return null;
        final parsed = double.tryParse(value.trim());
        if (parsed == null || parsed < 0) return 'Enter a valid value';
        return null;
      },
    );
  }

  Widget _textField(
    TextEditingController controller,
    String label, {
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label),
      validator: validator,
    );
  }
}

class _DateField extends StatelessWidget {
  const _DateField({required this.date, required this.onTap});

  final DateTime date;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: AppColors.surface,
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                'Record date: ${_format(date)}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            const Icon(Icons.calendar_today_outlined, size: 18),
          ],
        ),
      ),
    );
  }

  static String _format(DateTime date) {
    return '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}

class _WizardHeader extends StatelessWidget {
  const _WizardHeader({required this.step});

  final int step;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _bubble(context, 0, 'Birds', step >= 0),
        const SizedBox(width: 8),
        Expanded(
          child: Divider(
            color: step > 0
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.outlineVariant,
          ),
        ),
        const SizedBox(width: 8),
        _bubble(context, 1, 'Health', step >= 1),
      ],
    );
  }

  Widget _bubble(BuildContext context, int index, String label, bool active) {
    return Column(
      children: [
        CircleAvatar(
          radius: 14,
          backgroundColor: active
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.surfaceContainerHighest,
          child: Text(
            '${index + 1}',
            style: TextStyle(
              color: active
                  ? Colors.white
                  : Theme.of(context).colorScheme.onSurfaceVariant,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: Theme.of(context).textTheme.labelSmall),
      ],
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}
