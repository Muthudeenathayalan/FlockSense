class SettingsFeature {
  SettingsFeature._();
}
