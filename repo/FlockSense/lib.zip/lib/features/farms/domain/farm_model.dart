import 'package:cloud_firestore/cloud_firestore.dart';

class FarmModel {
  final String id;
  final String userId;
  final String? ownerId;
  final String farmName;
  final String? farmerName;
  final String farmType;   // 'EC' | 'Open'
  final String flockType;  // 'Broiler' | 'Layer' | 'Breeder' | 'Mixed'
  final String address;
  final String? areaName;
  final String? district;
  final String? state;
  final String? phoneNumber;
  final String? notes;
  final String status;
  final DateTime createdAt;
  final DateTime updatedAt;

  const FarmModel({
    required this.id,
    required this.userId,
    required this.farmName,
    required this.farmType,
    required this.flockType,
    required this.address,
    required this.createdAt,
    required this.updatedAt,
    this.ownerId,
    this.farmerName,
    this.areaName,
    this.district,
    this.state,
    this.phoneNumber,
    this.notes,
    this.status = 'active',
  });

  String? get ownerName => farmerName;
  String? get phone => phoneNumber;
  String? get location => areaName;

  factory FarmModel.fromJson(Map<String, dynamic> json) {
    DateTime _parseDate(dynamic v) {
      if (v is Timestamp) return v.toDate();
      if (v is String) return DateTime.tryParse(v) ?? DateTime.now();
      return DateTime.now();
    }

    return FarmModel(
      id: json['id'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      ownerId: json['ownerId'] as String? ?? json['userId'] as String?,
      farmName: json['farmName'] as String? ?? '',
      farmerName: json['farmerName'] as String? ?? json['ownerName'] as String?,
      farmType: json['farmType'] as String? ?? '',
      flockType: json['flockType'] as String? ?? '',
      address: json['address'] as String? ?? '',
      areaName: json['areaName'] as String? ?? json['location'] as String?,
      district: json['district'] as String?,
      state: json['state'] as String?,
      phoneNumber: json['phoneNumber'] as String? ?? json['phone'] as String?,
      notes: json['notes'] as String?,
      status: json['status'] as String? ?? 'active',
      createdAt: _parseDate(json['createdAt']),
      updatedAt: _parseDate(json['updatedAt']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'ownerId': ownerId,
        'farmName': farmName,
        'farmerName': farmerName,
        'farmType': farmType,
        'flockType': flockType,
        'address': address,
        'areaName': areaName,
        'district': district,
        'state': state,
        'phoneNumber': phoneNumber,
        'notes': notes,
        'status': status,
        'ownerName': farmerName,
        'phone': phoneNumber,
        'location': areaName,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  FarmModel copyWith({
    String? id,
    String? userId,
    String? ownerId,
    String? farmName,
    String? farmerName,
    String? farmType,
    String? flockType,
    String? address,
    String? areaName,
    String? district,
    String? state,
    String? phoneNumber,
    String? notes,
    String? status,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => FarmModel(
        id: id ?? this.id,
        userId: userId ?? this.userId,
        ownerId: ownerId ?? this.ownerId,
        farmName: farmName ?? this.farmName,
        farmerName: farmerName ?? this.farmerName,
        farmType: farmType ?? this.farmType,
        flockType: flockType ?? this.flockType,
        address: address ?? this.address,
        areaName: areaName ?? this.areaName,
        district: district ?? this.district,
        state: state ?? this.state,
        phoneNumber: phoneNumber ?? this.phoneNumber,
        notes: notes ?? this.notes,
        status: status ?? this.status,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
}
