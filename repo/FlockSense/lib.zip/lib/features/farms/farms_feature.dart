class FarmsFeature {
  FarmsFeature._();
}
