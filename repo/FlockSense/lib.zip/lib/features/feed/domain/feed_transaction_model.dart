import 'package:cloud_firestore/cloud_firestore.dart';

class FeedTransactionModel {
  const FeedTransactionModel({
    required this.id,
    required this.farmId,
    required this.batchId,
    required this.transactionDate,
    required this.transactionType,
    required this.feedType,
    this.feedBatchNumber,
    this.dcNumber,
    this.bags = 0,
    this.weightPerBagKg = 0,
    double? totalKg,
    this.supplierOrSource,
    this.destination,
    this.costPerKg = 0,
    this.totalCost = 0,
    this.notes,
    required this.ownerId,
    required this.createdAt,
    required this.updatedAt,
  }) : totalKg = totalKg != null && totalKg > 0
           ? totalKg
           : (bags > 0 && weightPerBagKg > 0 ? bags * weightPerBagKg : 0);

  final String id;
  final String farmId;
  final String batchId;
  final DateTime transactionDate;
  final String transactionType;
  final String feedType;
  final String? feedBatchNumber;
  final String? dcNumber;
  final int bags;
  final double weightPerBagKg;
  final double totalKg;
  final String? supplierOrSource;
  final String? destination;
  final double costPerKg;
  final double totalCost;
  final String? notes;
  final String ownerId;
  final DateTime createdAt;
  final DateTime updatedAt;

  factory FeedTransactionModel.fromJson(Map<String, dynamic> json) {
    DateTime parseDate(dynamic value) {
      if (value is Timestamp) return value.toDate();
      if (value is String && value.isNotEmpty) {
        return DateTime.tryParse(value) ?? DateTime.now();
      }
      return DateTime.now();
    }

    int parseInt(dynamic value) {
      if (value is int) return value;
      if (value is double) return value.toInt();
      if (value is String) return int.tryParse(value) ?? 0;
      return 0;
    }

    double parseDouble(dynamic value) {
      if (value is double) return value;
      if (value is int) return value.toDouble();
      if (value is String) return double.tryParse(value) ?? 0.0;
      return 0.0;
    }

    return FeedTransactionModel(
      id: json['id'] as String? ?? '',
      farmId: json['farmId'] as String? ?? '',
      batchId: json['batchId'] as String? ?? '',
      transactionDate: parseDate(json['transactionDate']),
      transactionType: json['transactionType'] as String? ?? 'received',
      feedType: json['feedType'] as String? ?? '',
      feedBatchNumber: json['feedBatchNumber'] as String?,
      dcNumber: json['dcNumber'] as String?,
      bags: parseInt(json['bags']),
      weightPerBagKg: parseDouble(json['weightPerBagKg']),
      totalKg: parseDouble(json['totalKg']),
      supplierOrSource: json['supplierOrSource'] as String?,
      destination: json['destination'] as String?,
      costPerKg: parseDouble(json['costPerKg']),
      totalCost: parseDouble(json['totalCost']),
      notes: json['notes'] as String?,
      ownerId: json['ownerId'] as String? ?? '',
      createdAt: parseDate(json['createdAt']),
      updatedAt: parseDate(json['updatedAt']),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'farmId': farmId,
    'batchId': batchId,
    'transactionDate': Timestamp.fromDate(transactionDate),
    'transactionType': transactionType,
    'feedType': feedType,
    'feedBatchNumber': feedBatchNumber,
    'dcNumber': dcNumber,
    'bags': bags,
    'weightPerBagKg': weightPerBagKg,
    'totalKg': totalKg,
    'supplierOrSource': supplierOrSource,
    'destination': destination,
    'costPerKg': costPerKg,
    'totalCost': totalCost,
    'notes': notes,
    'ownerId': ownerId,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
  };
}
