import 'package:flutter/material.dart';
import 'package:flock_sense/core/theme/app_colors.dart';
import 'package:flock_sense/features/feed/data/feed_service.dart';
import 'package:flock_sense/features/feed/domain/feed_transaction_model.dart';

class FeedTransactionFormScreen extends StatefulWidget {
  const FeedTransactionFormScreen({
    super.key,
    required this.farmId,
    required this.batchId,
    this.batchName,
    this.existingTransaction,
  });

  final String farmId;
  final String batchId;
  final String? batchName;
  final FeedTransactionModel? existingTransaction;

  @override
  State<FeedTransactionFormScreen> createState() =>
      _FeedTransactionFormScreenState();
}

class _FeedTransactionFormScreenState extends State<FeedTransactionFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late String _transactionType;
  late DateTime _transactionDate;
  final _feedTypeController = TextEditingController();
  final _feedBatchController = TextEditingController();
  final _dcNumberController = TextEditingController();
  final _bagsController = TextEditingController();
  final _weightPerBagController = TextEditingController();
  final _totalKgController = TextEditingController();
  final _supplierController = TextEditingController();
  final _destinationController = TextEditingController();
  final _costPerKgController = TextEditingController();
  final _totalCostController = TextEditingController();
  final _notesController = TextEditingController();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final existing = widget.existingTransaction;
    _transactionType = existing?.transactionType ?? 'received';
    _transactionDate = existing?.transactionDate ?? DateTime.now();
    _feedTypeController.text = existing?.feedType ?? '';
    _feedBatchController.text = existing?.feedBatchNumber ?? '';
    _dcNumberController.text = existing?.dcNumber ?? '';
    _bagsController.text = existing?.bags.toString() ?? '';
    _weightPerBagController.text = existing?.weightPerBagKg.toString() ?? '';
    _totalKgController.text = existing?.totalKg.toString() ?? '';
    _supplierController.text = existing?.supplierOrSource ?? '';
    _destinationController.text = existing?.destination ?? '';
    _costPerKgController.text = existing?.costPerKg.toString() ?? '';
    _totalCostController.text = existing?.totalCost.toString() ?? '';
    _notesController.text = existing?.notes ?? '';
  }

  @override
  void dispose() {
    _feedTypeController.dispose();
    _feedBatchController.dispose();
    _dcNumberController.dispose();
    _bagsController.dispose();
    _weightPerBagController.dispose();
    _totalKgController.dispose();
    _supplierController.dispose();
    _destinationController.dispose();
    _costPerKgController.dispose();
    _totalCostController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _transactionDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() => _transactionDate = picked);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    try {
      final bags = int.tryParse(_bagsController.text.trim()) ?? 0;
      final weightPerBag =
          double.tryParse(_weightPerBagController.text.trim()) ?? 0;
      final explicitTotalKg = double.tryParse(_totalKgController.text.trim());
      final totalKg =
          explicitTotalKg ??
          ((bags > 0 && weightPerBag > 0) ? bags * weightPerBag : 0);
      final costPerKg = double.tryParse(_costPerKgController.text.trim()) ?? 0;
      final explicitTotalCost = double.tryParse(_totalCostController.text.trim());
      final totalCost = explicitTotalCost ?? (costPerKg > 0 && totalKg > 0 ? costPerKg * totalKg : 0);

      if (widget.existingTransaction == null) {
        await FeedService.createFeedTransaction(
          farmId: widget.farmId,
          batchId: widget.batchId,
          transactionDate: _transactionDate,
          transactionType: _transactionType,
          feedType: _feedTypeController.text.trim(),
          feedBatchNumber: _feedBatchController.text.trim().isEmpty
              ? null
              : _feedBatchController.text.trim(),
          dcNumber: _dcNumberController.text.trim().isEmpty
              ? null
              : _dcNumberController.text.trim(),
          bags: bags,
          weightPerBagKg: weightPerBag,
          totalKg: totalKg,
          supplierOrSource: _supplierController.text.trim().isEmpty
              ? null
              : _supplierController.text.trim(),
          destination: _destinationController.text.trim().isEmpty
              ? null
              : _destinationController.text.trim(),
          costPerKg: costPerKg,
          totalCost: totalCost,
          notes: _notesController.text.trim().isEmpty
              ? null
              : _notesController.text.trim(),
        );
      } else {
        await FeedService.updateFeedTransaction(
          farmId: widget.farmId,
          batchId: widget.batchId,
          transactionId: widget.existingTransaction!.id,
          transactionDate: _transactionDate,
          transactionType: _transactionType,
          feedType: _feedTypeController.text.trim(),
          feedBatchNumber: _feedBatchController.text.trim().isEmpty
              ? null
              : _feedBatchController.text.trim(),
          dcNumber: _dcNumberController.text.trim().isEmpty
              ? null
              : _dcNumberController.text.trim(),
          bags: bags,
          weightPerBagKg: weightPerBag,
          totalKg: totalKg,
          supplierOrSource: _supplierController.text.trim().isEmpty
              ? null
              : _supplierController.text.trim(),
          destination: _destinationController.text.trim().isEmpty
              ? null
              : _destinationController.text.trim(),
          costPerKg: costPerKg,
          totalCost: totalCost,
          notes: _notesController.text.trim().isEmpty
              ? null
              : _notesController.text.trim(),
        );
      }

      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Feed transaction saved')));
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Save failed: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          widget.batchName != null
              ? 'Feed • ${widget.batchName}'
              : 'Feed transaction',
        ),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.primary,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                value: _transactionType,
                decoration: _inputDecoration('Transaction type'),
                items: const [
                  DropdownMenuItem(value: 'received', child: Text('Received')),
                  DropdownMenuItem(
                    value: 'transferIn',
                    child: Text('Transfer In'),
                  ),
                  DropdownMenuItem(
                    value: 'transferOut',
                    child: Text('Transfer Out'),
                  ),
                  DropdownMenuItem(
                    value: 'adjustmentAdd',
                    child: Text('Adjustment Add'),
                  ),
                  DropdownMenuItem(
                    value: 'adjustmentRemove',
                    child: Text('Adjustment Remove'),
                  ),
                ],
                onChanged: (value) =>
                    setState(() => _transactionType = value ?? 'received'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 14),
              InkWell(
                onTap: _pickDate,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 16,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Transaction date',
                        style: TextStyle(color: AppColors.textSecondary),
                      ),
                      Text(
                        _formatDate(_transactionDate),
                        style: const TextStyle(color: AppColors.textPrimary),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              _textField(_feedTypeController, 'Feed type', required: true),
              const SizedBox(height: 14),
              _textField(_feedBatchController, 'Feed batch number'),
              const SizedBox(height: 14),
              _textField(_dcNumberController, 'DC number'),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _textField(
                      _bagsController,
                      'Bags',
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _textField(
                      _weightPerBagController,
                      'Weight per bag (kg)',
                      keyboardType: TextInputType.number,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _textField(
                _totalKgController,
                'Total kg',
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 14),
              _textField(_supplierController, 'Supplier / source'),
              const SizedBox(height: 14),
              _textField(
                _destinationController,
                'Destination',
                required: _transactionType == 'transferOut',
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _textField(
                      _costPerKgController,
                      'Cost per kg',
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _textField(
                      _totalCostController,
                      'Total cost',
                      keyboardType: TextInputType.number,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _textField(_notesController, 'Notes', maxLines: 3),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _saving ? null : _save,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                ),
                child: _saving
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('Save transaction'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _textField(
    TextEditingController controller,
    String label, {
    bool required = false,
    int maxLines = 1,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: _inputDecoration(label),
      validator: required
          ? (value) =>
                (value == null || value.trim().isEmpty) ? 'Required' : null
          : null,
    );
  }

  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: AppColors.surface,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.border),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}
