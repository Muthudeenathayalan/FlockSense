import 'package:flutter/material.dart';
import 'package:flock_sense/core/theme/app_colors.dart';

class VaccineRecordsScreen extends StatelessWidget {
  const VaccineRecordsScreen({
    super.key,
    this.farmId,
    this.batchId,
    this.batchName,
  });

  final String? farmId;
  final String? batchId;
  final String? batchName;

  bool get _hasContext =>
      (farmId?.isNotEmpty ?? false) && (batchId?.isNotEmpty ?? false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
          batchName == null ? 'Vaccination' : 'Vaccination • $batchName',
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Vaccine tracker',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _hasContext
                        ? 'Keep schedule, dose, and vaccine lot details for this batch.'
                        : 'Open this screen from a batch to schedule and log vaccinations.',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: const [
                  Icon(
                    Icons.vaccines_outlined,
                    size: 56,
                    color: AppColors.textHint,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'No vaccine records yet',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Vaccine schedule and administration logs will appear here.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: _hasContext
          ? FloatingActionButton.extended(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Vaccine form will be added in the next pass.',
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Add Vaccine'),
            )
          : null,
    );
  }
}
