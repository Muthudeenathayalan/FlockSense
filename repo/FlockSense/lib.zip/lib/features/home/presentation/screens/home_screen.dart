import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flock_sense/config/routes/app_routes.dart';
import 'package:flock_sense/core/theme/app_colors.dart';
import 'package:flock_sense/features/batches/data/batch_service.dart';
import 'package:flock_sense/features/daily_records/data/daily_record_service.dart';
import 'package:flock_sense/features/farms/data/farm_service.dart';
import 'package:flock_sense/features/farms/domain/farm_model.dart';
import 'package:flock_sense/features/farms/presentation/screens/farm_command_center_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<_HomeData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<_HomeData> _load() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return _HomeData.empty;

    final farms = await FarmService.getUserFarms(forceRefresh: true);
    final totalFarmArea = await FarmService.getUserFarmArea(user.uid);
    final activeBatchCount = await BatchService.getUserActiveBatchCount(
      user.uid,
    );
    final liveBirds = await BatchService.getUserLiveBirdCount(user.uid);
    final todayMortality = await DailyRecordService.getTodayMortalityCount(user.uid);

    final userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();
    final activeFarmId = userDoc.data()?['activeFarmId'] as String?;

    FarmModel? activeFarm;
    if (activeFarmId != null) {
      for (final farm in farms) {
        if (farm.id == activeFarmId) {
          activeFarm = farm;
          break;
        }
      }
    }

    return _HomeData(
      farms: farms,
      activeFarm: activeFarm,
      activeBatchCount: activeBatchCount,
      totalFarmArea: totalFarmArea,
      liveBirds: liveBirds,
      todayMortality: todayMortality,
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final displayName = user?.displayName?.trim();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('FlockSense'),
        actions: [
          IconButton(
            onPressed: _refresh,
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: FutureBuilder<_HomeData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 52),
                    const SizedBox(height: 10),
                    const Text('Unable to load dashboard right now.'),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: _refresh,
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            );
          }

          final data = snapshot.data ?? _HomeData.empty;
          final mortalitySummary = data.todayMortality.toString();

          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
              children: [
                Text(
                  displayName == null || displayName.isEmpty
                      ? 'Command Center'
                      : 'Welcome, $displayName',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 6),
                Text(
                  data.farms.isEmpty
                      ? 'Start by creating your first farm.'
                      : 'Track farms, batches, and live flock health from one place.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 14),
                if (data.farms.isEmpty)
                  _EmptyStartCard(
                    onCreateFarm: () =>
                        Navigator.pushNamed(context, AppRoutes.farmSetup),
                  )
                else ...[
                  _OverviewCard(
                    farms: data.farms.length,
                    areaSqFt: data.totalFarmArea,
                    activeBatches: data.activeBatchCount,
                    liveBirds: data.liveBirds,
                    mortalitySummary: mortalitySummary,
                  ),
                  const SizedBox(height: 14),
                  if (data.activeFarm != null)
                    _ActiveFarmCard(activeFarm: data.activeFarm!),
                  const SizedBox(height: 14),
                  _OperationsCard(
                    onManageFarms: () {
                      Navigator.pushNamed(context, AppRoutes.farms);
                    },
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class _HomeData {
  const _HomeData({
    required this.farms,
    required this.activeFarm,
    required this.activeBatchCount,
    required this.totalFarmArea,
    required this.liveBirds,
    required this.todayMortality,
  });

  final List<FarmModel> farms;
  final FarmModel? activeFarm;
  final int activeBatchCount;
  final double totalFarmArea;
  final int liveBirds;
  final int todayMortality;

  static const empty = _HomeData(
    farms: <FarmModel>[],
    activeFarm: null,
    activeBatchCount: 0,
    totalFarmArea: 0,
    liveBirds: 0,
    todayMortality: 0,
  );
}

class _EmptyStartCard extends StatelessWidget {
  const _EmptyStartCard({required this.onCreateFarm});

  final VoidCallback onCreateFarm;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Start your first farm',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            const Text(
              'Create a farm to unlock batch placement and daily records.',
            ),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: onCreateFarm,
              icon: const Icon(Icons.add),
              label: const Text('Create Farm'),
            ),
          ],
        ),
      ),
    );
  }
}

class _OverviewCard extends StatelessWidget {
  const _OverviewCard({
    required this.farms,
    required this.areaSqFt,
    required this.activeBatches,
    required this.liveBirds,
    required this.mortalitySummary,
  });

  final int farms;
  final double areaSqFt;
  final int activeBatches;
  final int liveBirds;
  final String mortalitySummary;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Farm Overview',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _MetricChip(label: 'Farms', value: farms.toString()),
                _MetricChip(
                  label: 'Area',
                  value: '${areaSqFt.toStringAsFixed(0)} ft\u00b2',
                ),
                _MetricChip(
                  label: 'Active batches',
                  value: activeBatches.toString(),
                ),
                _MetricChip(label: 'Live birds', value: liveBirds.toString()),
                _MetricChip(label: 'Mortality', value: mortalitySummary),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricChip extends StatelessWidget {
  const _MetricChip({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 140),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: AppColors.surfaceSoft,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: Theme.of(context).textTheme.labelSmall),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _ActiveFarmCard extends StatelessWidget {
  const _ActiveFarmCard({required this.activeFarm});

  final FarmModel activeFarm;

  @override
  Widget build(BuildContext context) {
    final location = [
      activeFarm.areaName,
      activeFarm.district,
      activeFarm.state,
    ].whereType<String>().where((value) => value.trim().isNotEmpty).join(', ');

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Active farm', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(
              activeFarm.farmName,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 6),
            Text(location.isEmpty ? 'No location set' : location),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => FarmCommandCenterScreen(farm: activeFarm),
                  ),
                );
              },
              child: const Text('Open Active Farm'),
            ),
          ],
        ),
      ),
    );
  }
}

class _OperationsCard extends StatelessWidget {
  const _OperationsCard({required this.onManageFarms});

  final VoidCallback onManageFarms;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Operations', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            const Text('Use bottom Add Records for fast daily entry.'),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: onManageFarms,
              icon: const Icon(Icons.agriculture_outlined),
              label: const Text('Manage Farms'),
            ),
          ],
        ),
      ),
    );
  }
}
