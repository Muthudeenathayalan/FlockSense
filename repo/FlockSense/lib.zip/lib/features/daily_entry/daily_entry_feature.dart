class DailyEntryFeature {
  DailyEntryFeature._();
}
