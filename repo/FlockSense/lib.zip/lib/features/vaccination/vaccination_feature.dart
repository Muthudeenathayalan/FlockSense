class VaccinationFeature {
  VaccinationFeature._();
}
