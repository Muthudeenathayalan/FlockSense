import 'package:flutter/material.dart';
import 'package:flock_sense/core/theme/app_colors.dart';
import 'package:flock_sense/features/batches/data/batch_service.dart';
import 'package:flock_sense/features/batches/domain/batch_model.dart';
import 'package:flock_sense/features/daily_records/data/daily_record_service.dart';
import 'package:flock_sense/features/daily_records/domain/daily_record_model.dart';
import 'package:flock_sense/features/daily_records/presentation/screens/daily_record_form_screen.dart';
import 'package:flock_sense/features/daily_records/presentation/screens/daily_records_screen.dart';
import 'package:flock_sense/features/feed/presentation/screens/feed_records_screen.dart';
import 'package:flock_sense/features/medicine/presentation/screens/medicine_records_screen.dart';
import 'package:flock_sense/features/sales/presentation/screens/bird_sales_screen.dart';
import 'package:flock_sense/features/reports/presentation/screens/reports_screen.dart';
import 'package:flock_sense/features/vaccine/presentation/screens/vaccine_records_screen.dart';

class BatchCommandCenterScreen extends StatelessWidget {
  const BatchCommandCenterScreen({
    super.key,
    required this.farmId,
    required this.batchId,
    this.batchName,
  });

  final String farmId;
  final String batchId;
  final String? batchName;

  Future<_BatchCommandCenterData> _loadData() async {
    final batch = await BatchService.getBatchById(farmId, batchId);
    final latestRecord = await DailyRecordService.getBatchLatestRecord(
      farmId: farmId,
      batchId: batchId,
    );
    return _BatchCommandCenterData(batch: batch, latestRecord: latestRecord);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Batch Command Center'),
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.primary,
      ),
      body: FutureBuilder<_BatchCommandCenterData>(
        future: _loadData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final batch = snapshot.data?.batch;
          final latestRecord = snapshot.data?.latestRecord;
          final recordToday =
              latestRecord != null &&
              _isSameDay(latestRecord.recordDate, DateTime.now());

          final title = batch?.batchName ?? batchName ?? 'Batch';
          final status = batch?.status ?? 'Unknown';
          final currentBirds = batch?.currentBirds ?? 0;
          final totalBirds = batch?.totalBirds ?? 0;
          final ageText = batch != null
              ? _ageDaysText(batch.placementDate)
              : 'Age unavailable';
          final todayStatus = recordToday ? 'Completed' : 'Pending';

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border),
                    boxShadow: const [
                      BoxShadow(
                        color: AppColors.shadow,
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        status.toUpperCase(),
                        style: const TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          _StatTile(
                            label: 'Current birds',
                            value: currentBirds.toString(),
                          ),
                          const SizedBox(width: 12),
                          _StatTile(
                            label: 'Total birds',
                            value: totalBirds.toString(),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _StatTile(label: 'Age', value: ageText),
                          const SizedBox(width: 12),
                          _StatTile(label: 'Today record', value: todayStatus),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Quick Actions',
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.1,
                  children: [
                    _ActionCard(
                      label: 'Add Today Record',
                      icon: Icons.today_outlined,
                      onTap: () async {
                        final todayRecord =
                            await DailyRecordService.getDailyRecordByDate(
                              farmId: farmId,
                              batchId: batchId,
                              recordDate: DateTime.now(),
                            );
                        if (!context.mounted) return;
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DailyRecordFormScreen(
                              farmId: farmId,
                              batchId: batchId,
                              batchName: title,
                              existingRecord: todayRecord,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      label: 'Daily Records',
                      icon: Icons.list_alt,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DailyRecordsScreen(
                              farmId: farmId,
                              batchId: batchId,
                              batchName: title,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      label: 'Feed',
                      icon: Icons.food_bank_outlined,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => FeedRecordsScreen(
                              farmId: farmId,
                              batchId: batchId,
                              batchName: title,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      label: 'Medicine',
                      icon: Icons.medical_services_outlined,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MedicineRecordsScreen(
                              farmId: farmId,
                              batchId: batchId,
                              batchName: title,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      label: 'Vaccine',
                      icon: Icons.vaccines_outlined,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => VaccineRecordsScreen(
                              farmId: farmId,
                              batchId: batchId,
                              batchName: title,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      label: 'Sales',
                      icon: Icons.attach_money,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BirdSalesScreen(
                              farmId: farmId,
                              batchId: batchId,
                              batchName: title,
                            ),
                          ),
                        );
                      },
                    ),
                    _ActionCard(
                      label: 'Reports',
                      icon: Icons.bar_chart_outlined,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const ReportsScreen(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Latest record',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (latestRecord == null)
                        const Text(
                          'No daily record yet. Start tracking today.',
                          style: TextStyle(color: AppColors.textSecondary),
                        )
                      else ...[
                        _InfoRow(
                          label: 'Date',
                          value: _formatDisplayDate(latestRecord.recordDate),
                        ),
                        _InfoRow(
                          label: 'Mortality',
                          value: latestRecord.mortalityCount.toString(),
                        ),
                        _InfoRow(
                          label: 'Feed',
                          value:
                              '${latestRecord.feedConsumedKg.toStringAsFixed(1)} kg',
                        ),
                        _InfoRow(
                          label: 'Closing birds',
                          value: latestRecord.closingBirds.toString(),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  String _ageDaysText(DateTime placementDate) {
    final days = DateTime.now().difference(placementDate).inDays;
    if (days < 0) return '0 day';
    return '$days day${days == 1 ? '' : 's'}';
  }

  static bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  static String _formatDisplayDate(DateTime date) {
    return '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}

class _BatchCommandCenterData {
  const _BatchCommandCenterData({
    required this.batch,
    required this.latestRecord,
  });

  final BatchModel? batch;
  final DailyRecordModel? latestRecord;
}

class _StatTile extends StatelessWidget {
  const _StatTile({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surfaceSoft,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Icon(icon, color: AppColors.primary, size: 26),
            const Spacer(),
            Text(
              label,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary)),
          Text(
            value,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
