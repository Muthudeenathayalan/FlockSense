class BatchesFeature {
  BatchesFeature._();
}
