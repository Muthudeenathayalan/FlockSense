class ShedsFeature {
  ShedsFeature._();
}
