/// Application API and Service Configurations
///
/// Set the Gemini API key via '--dart-define=GEMINI_API_KEY=your_key' or
/// provide it dynamically in app settings / this configuration.
class ApiConfig {
  ApiConfig._();

  /// Google Gemini API Key for FlockSense AI Advisor.
  /// Overridden dynamically if passed via --dart-define=GEMINI_API_KEY=...
  static final String geminiApiKey = const bool.hasEnvironment('GEMINI_API_KEY')
      ? const String.fromEnvironment('GEMINI_API_KEY')
      : 'AQ.Ab8RN6JWnurKtnN53aiFRnT7sD8qNhrZ8R8l4P2CGPZLVIrJ4Q';
}

